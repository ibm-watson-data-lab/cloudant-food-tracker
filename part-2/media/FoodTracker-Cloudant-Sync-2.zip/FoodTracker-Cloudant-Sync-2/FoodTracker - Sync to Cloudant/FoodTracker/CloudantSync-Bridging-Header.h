//
//  CloudantSync-Bridging-Header.h
//  FoodTracker
//
//  Created by Jason Smith on 1/23/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//

#ifndef CloudantSync_Bridging_Header_h
#define CloudantSync_Bridging_Header_h

#import <CloudantSync.h>

#endif /* CloudantSync_Bridging_Header_h */
